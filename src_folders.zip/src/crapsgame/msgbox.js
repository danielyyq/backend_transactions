import Game from '../crapsgame/Maingame'
import Obj from '../crapsgame/animation'
import {Font, Color} from '../crapsgame/font'


export var MessageBox =
{
    Hide : function()
    {
        Game.HotSpot.ButtonMsgBox.Disable();
        Obj("msgbox").Hide();
        setTimeout(Game.Update, 1);
    },

    Show : function(title, text)
    {
        Game.DisableInput();

        Obj("msgbox_title").innerHTML = Font.Write(Color.White, title);
        Obj("msgbox_text" ).innerHTML = Font.Write(Color.Black, text );

        Obj("msgbox").Show();

        Game.HotSpot.ButtonMsgBox.Enable();
    }
};
