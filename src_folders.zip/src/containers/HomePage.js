var React = require('react');

class HomePage extends React.Component {
  render() {
    return (
      <div className="container">
        <h1>Welcome to Crypto Craps.</h1>
        <p><br></br></p>
        <p>This is a popular casino game made in BlockChain Technology and programmed wtih distributed functional programming model.
        </p>
      </div>
    );
  }
};

export default HomePage;
