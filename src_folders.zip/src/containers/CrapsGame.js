 /* eslint-disable */
import Game from '../crapsgame/Maingame'
var React = require('react');

class CrapsGame extends React.Component {
  render() {
    return (
      <div>
      <meta httpEquiv="content-type" content="text/html; charset=utf-8" />
      <meta content="width=device-width, initial-scale=1.0, user-scalable=no" name="viewport" />
      <title>Craps Game</title>
      <div className="main">
        <div className="content content--is-centered">
          <div className="content-body">
            <h1 className="page-title">Play Craps</h1>
            <br />
            <p className="intro" />
          </div>{/*/content-body*/}
          <div className="content-app">
            <p>
              <input type="checkbox" id="BetsOn"  /><label htmlFor="BetsOn" title="Enable to leave buy bets, come odds, and hardway bets working on come-out rolls"> Leave bets working</label> &nbsp;
              <input type="checkbox" id="BetsUp" /><label htmlFor="BetsUp" title="Enable to leave winning bets up"> Leave winning bets up</label>
            </p>
            <link rel="stylesheet" type="text/css" href="../crapsgame/img/craps.css" />
            <div id="loading"><noscript>You must enable JavaScript in order to play this game.</noscript></div>
            <div id="cache">
              <img src="../crapsgame/img/button.png" />
              <img src="../crapsgame/img/chip.png" />
              <img src="../crapsgame/img/chip-selector.png" />
              <img src="../crapsgame/img/dice.png" />
              <img src="../crapsgame/img/font-black.png" />
              <img src="../crapsgame/img/font-blue.png" />
              <img src="../crapsgame/img/font-cyan.png" />
              <img src="../crapsgame/img/font-green.png" />
              <img src="../crapsgame/img/font-magenta.png" />
              <img src="../crapsgame/img/font-red.png" />
              <img src="../crapsgame/img/font-white.png" />
              <img src="../crapsgame/img/font-yellow.png" />
              <img src="../crapsgame/img/game.png" />
              <img src="../crapsgame/img/msgbox.png" />
              <img src="../crapsgame/img/puck.png" />
              <img src="../crapsgame/img/trans.gif" />
              <img src="../crapsgame/img/wager.png" />
            </div>
            <div id="game" className="gameTransform">
              <div id="message" />
              <div className="wager" id="PassLine" />
              <div className="wager" id="PassLineOdds" />
              <div className="wager" id="DontPass" />
              <div className="wager" id="DontPassOdds" />
              <div className="wager" id="Field" />
              <div className="wager" id="Come" />
              <div className="wager" id="DontCome" />
              <div className="wager" id="Lay4" />
              <div className="wager" id="Lay5" />
              <div className="wager" id="Lay6" />
              <div className="wager" id="Lay8" />
              <div className="wager" id="Lay9" />
              <div className="wager" id="Lay10" />
              <div className="wager" id="DontCome4" />
              <div className="wager" id="DontCome5" />
              <div className="wager" id="DontCome6" />
              <div className="wager" id="DontCome8" />
              <div className="wager" id="DontCome9" />
              <div className="wager" id="DontCome10" />
              <div className="wager" id="DontCome4Odds" />
              <div className="wager" id="DontCome5Odds" />
              <div className="wager" id="DontCome6Odds" />
              <div className="wager" id="DontCome8Odds" />
              <div className="wager" id="DontCome9Odds" />
              <div className="wager" id="DontCome10Odds" />
              <div className="wager" id="Come4" />
              <div className="wager" id="Come5" />
              <div className="wager" id="Come6" />
              <div className="wager" id="Come8" />
              <div className="wager" id="Come9" />
              <div className="wager" id="Come10" />
              <div className="wager" id="Come4Odds" />
              <div className="wager" id="Come5Odds" />
              <div className="wager" id="Come6Odds" />
              <div className="wager" id="Come8Odds" />
              <div className="wager" id="Come9Odds" />
              <div className="wager" id="Come10Odds" />
              <div className="wager" id="Buy4" />
              <div className="wager" id="Buy5" />
              <div className="wager" id="Buy6" />
              <div className="wager" id="Buy8" />
              <div className="wager" id="Buy9" />
              <div className="wager" id="Buy10" />
              <div className="wager" id="AnySeven" />
              <div className="wager" id="Hard4" />
              <div className="wager" id="Hard6" />
              <div className="wager" id="Hard8" />
              <div className="wager" id="Hard10" />
              <div className="wager" id="Three" />
              <div className="wager" id="Eleven" />
              <div className="wager" id="Two" />
              <div className="wager" id="Twelve" />
              <div className="wager" id="AnyCraps" />
              <div id="PassLine_stack" />
              <div id="PassLineOdds_stack" />
              <div id="DontPass_stack" />
              <div id="DontPassOdds_stack" />
              <div id="Field_stack" />
              <div id="Come_stack" />
              <div id="DontCome_stack" />
              <div id="Lay4_stack" />
              <div id="Lay5_stack" />
              <div id="Lay6_stack" />
              <div id="Lay8_stack" />
              <div id="Lay9_stack" />
              <div id="Lay10_stack" />
              <div id="DontCome4_stack" />
              <div id="DontCome5_stack" />
              <div id="DontCome6_stack" />
              <div id="DontCome8_stack" />
              <div id="DontCome9_stack" />
              <div id="DontCome10_stack" />
              <div id="DontCome4Odds_stack" />
              <div id="DontCome5Odds_stack" />
              <div id="DontCome6Odds_stack" />
              <div id="DontCome8Odds_stack" />
              <div id="DontCome9Odds_stack" />
              <div id="DontCome10Odds_stack" />
              <div id="Come4_stack" />
              <div id="Come5_stack" />
              <div id="Come6_stack" />
              <div id="Come8_stack" />
              <div id="Come9_stack" />
              <div id="Come10_stack" />
              <div id="Come4Odds_stack" />
              <div id="Come5Odds_stack" />
              <div id="Come6Odds_stack" />
              <div id="Come8Odds_stack" />
              <div id="Come9Odds_stack" />
              <div id="Come10Odds_stack" />
              <div id="Buy4_stack" />
              <div id="Buy5_stack" />
              <div id="Buy6_stack" />
              <div id="Buy8_stack" />
              <div id="Buy9_stack" />
              <div id="Buy10_stack" />
              <div id="AnySeven_stack" />
              <div id="Hard4_stack" />
              <div id="Hard6_stack" />
              <div id="Hard8_stack" />
              <div id="Hard10_stack" />
              <div id="Three_stack" />
              <div id="Eleven_stack" />
              <div id="Two_stack" />
              <div id="Twelve_stack" />
              <div id="AnyCraps_stack" />
              <div id="PassLine_slider" />
              <div id="PassLineOdds_slider" />
              <div id="DontPass_slider" />
              <div id="DontPassOdds_slider" />
              <div id="Field_slider" />
              <div id="Come_slider" />
              <div id="DontCome_slider" />
              <div id="Lay4_slider" />
              <div id="Lay5_slider" />
              <div id="Lay6_slider" />
              <div id="Lay8_slider" />
              <div id="Lay9_slider" />
              <div id="Lay10_slider" />
              <div id="DontCome4_slider" />
              <div id="DontCome5_slider" />
              <div id="DontCome6_slider" />
              <div id="DontCome8_slider" />
              <div id="DontCome9_slider" />
              <div id="DontCome10_slider" />
              <div id="DontCome4Odds_slider" />
              <div id="DontCome5Odds_slider" />
              <div id="DontCome6Odds_slider" />
              <div id="DontCome8Odds_slider" />
              <div id="DontCome9Odds_slider" />
              <div id="DontCome10Odds_slider" />
              <div id="Come4_slider" />
              <div id="Come5_slider" />
              <div id="Come6_slider" />
              <div id="Come8_slider" />
              <div id="Come9_slider" />
              <div id="Come10_slider" />
              <div id="Come4Odds_slider" />
              <div id="Come5Odds_slider" />
              <div id="Come6Odds_slider" />
              <div id="Come8Odds_slider" />
              <div id="Come9Odds_slider" />
              <div id="Come10Odds_slider" />
              <div id="Buy4_slider" />
              <div id="Buy5_slider" />
              <div id="Buy6_slider" />
              <div id="Buy8_slider" />
              <div id="Buy9_slider" />
              <div id="Buy10_slider" />
              <div id="AnySeven_slider" />
              <div id="Hard4_slider" />
              <div id="Hard6_slider" />
              <div id="Hard8_slider" />
              <div id="Hard10_slider" />
              <div id="Three_slider" />
              <div id="Eleven_slider" />
              <div id="Two_slider" />
              <div id="Twelve_slider" />
              <div id="AnyCraps_slider" />
              <div id="puck"><img id="puckimg" src="puck.png" /></div>
              <div className="puckoff" id="Come4Off" />
              <div className="puckoff" id="Come5Off" />
              <div className="puckoff" id="Come6Off" />
              <div className="puckoff" id="Come8Off" />
              <div className="puckoff" id="Come9Off" />
              <div className="puckoff" id="Come10Off" />
              <div className="puckoff" id="Buy4Off" />
              <div className="puckoff" id="Buy5Off" />
              <div className="puckoff" id="Buy6Off" />
              <div className="puckoff" id="Buy8Off" />
              <div className="puckoff" id="Buy9Off" />
              <div className="puckoff" id="Buy10Off" />
              <div className="puckoff" id="Hard4Off" />
              <div className="puckoff" id="Hard6Off" />
              <div className="puckoff" id="Hard8Off" />
              <div className="puckoff" id="Hard10Off" />
              <div id="die1" />
              <div id="die2" />
              <div id="balance" />
              <div id="denom" />
              <div id="denom0" />
              <div id="denom1" />
              <div id="denom2" />
              <div id="denom3" />
              <div id="wager" />
              <div id="win" />
              <div id="btn_roll" />
              <div id="btn_clear" />
              <div id="msgbox">
                <div id="msgbox_title" />
                <div id="msgbox_prompt"><table><tbody><tr><td id="msgbox_text" /></tr></tbody></table></div>
                <div id="msgbox_button" />
              </div>
              <div id="capture" />
            </div>
          </div>{/*/content-app*/}
          <div className="content-body">
            <p><strong>Rules</strong></p>
            <ol>
              <li>3-4-5X odds are allowed.</li>
              <li>To simplify the game, instead of offering both place and buy bets, I offer just one for each number.  Each number pays the better odds between place and buy bets.  I refer to these as "buy bets."  They  pay 7-6 on the 6 &amp; 8, 7-5 on the 5 &amp; 9, and 39-20 on the 4 &amp; 10.</li>
              <li>Lay bets pay true odds, but player must prepay a 5% commission, based on the possible win.  This works out to odds of 19-25 on the 6 &amp; 8, 19-31 on the 5 &amp; 9, and 19-41 on the 4 &amp; 10.</li>
              <li>If the player selects "keep bets working," then all bets will be on for come out rolls.  Otherwise, buy, hard ways, and odds on come bets will be turned off.</li>
            </ol><br />
            <p>To slow down the payment stage of the game, hold down the shift and control keys when you click "roll."</p>
          </div>{/*/content-body*/}
        </div>
      </div>
    </div>
    );
};};

export default CrapsGame;
