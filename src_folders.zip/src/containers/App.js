import React from 'react'
import NavBar from '../components/nav/NavBar'

const navdata = [{"title": "Home", "href": "/home"}, {"title": "Game", "href": "/game_craps"}, {"title": "Transactions", "href": "/transactions"}
]

class App extends React.Component {

    render() {
      return (
        <div>
          <NavBar navData={navdata}/>
          <hr/>
          {this.props.children}
        </div>
      )
    }
}

export default App
