
var resonseJson = "";
export const getXCCYRateFromApiAsync = () => {
  return fetch('https://min-api.cryptocompare.com/data/price?fsym=ETH&tsyms=USD,CAD,EUR')
  .then((response) => response.json())
  .then((_resonseJson) => {
    resonseJson = _resonseJson;
    return resonseJson.CAD;
  })
  .catch((error) => {
    console.error(error);
  });
}

export const getCADRate = (_resonseJson) => {
  return _resonseJson.CAD;
}

export const getUSDRate = (_resonseJson) => {
  return _resonseJson.USD;
}

export const getEURRate = (_resonseJson) => {
  return _resonseJson.EUR;
}
