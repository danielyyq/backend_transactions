/**
 * Ethereum service API
 */
import Web3 from 'web3'
import { getBalance, sendCoin } from './metacoin'
import {getXCCYRateFromApiAsync} from './XccyRate'
const web3 = new Web3(new Web3.providers.HttpProvider('http://localhost:8545'))

var CADRate = 1;

export default {

  getAccounts: (cb) => {
    web3.eth.getAccounts(async function(error, addresses) {
      let _accounts = [];
      console.log("this is the value of before update:  " + CADRate);
      CADRate = await getXCCYRateFromApiAsync();
      console.log("this is the value after update: "+ CADRate);
      for (var i = 0; i < addresses.length; i++) {
        let eth = web3.fromWei(web3.eth.getBalance(addresses[i]), 'ether')
        _accounts.push({
          address: addresses[i],
          balance: eth,
          cadCoin: eth * CADRate,
          meta: await getBalance(addresses[i])
        })
      }
      cb(_accounts);
    })
  },
  transfer: (transaction) => {

    if (transaction.crypto === 'ETH') {
      const amount = web3.toWei(transaction.amount, "ether")

      return web3.eth.sendTransaction({from:transaction.from, to:transaction.to, value: amount})
    } else {
      return sendCoin(transaction)
    }
  }



}
